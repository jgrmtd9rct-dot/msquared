# Asset notices

Theme PHP and JavaScript: GPL-2.0-or-later. Studio logos, photographs, portfolio work, and publications retain their original owners’ rights; inclusion does not grant unrelated reuse rights.

Plus Jakarta Sans and Geist Mono: SIL Open Font License, copies included. The preserved career design loads Inter and Newsreader from Google Fonts.

Lucide icons: ISC license, https://github.com/lucide-icons/lucide/blob/main/LICENSE . Compiled stylesheet includes Tailwind CSS and animation/component utilities from the original project; their upstream licenses apply (Tailwind CSS MIT, tw-animate-css MIT, shadcn MIT).
