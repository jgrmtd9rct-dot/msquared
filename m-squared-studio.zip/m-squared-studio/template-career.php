<?php
/* Template Name: Preserved Career Portfolio */
if (!defined('ABSPATH')) { exit; }
$html = file_get_contents(__DIR__.'/templates/career.html');
$html = preg_replace_callback('~(?:https://m2digital\.studio)?(/wp-content/uploads/[^\s"\'<>]+)~', function($m) { return esc_url(m2_url($m[1])); }, $html);
$html = preg_replace('/<meta\s+name=["\']theme-color["\'][^>]*>/i', '', $html);
function m2_career_data($value) {
    if (is_array($value) && isset($value['field'])) {
        $field=m2_fields()[$value['field']]; $text=m2_value($value['field']);
        return in_array($field['type'],array('url','image'),true) ? esc_url(m2_url($text)) : esc_html($text);
    }
    if (is_array($value)) { return array_map('m2_career_data',$value); }
    return $value;
}
$career_data=json_decode(file_get_contents(__DIR__.'/inc/career-data.json'),true);
$html=preg_replace_callback('/\{\{json:([a-zA-Z]+)\}\}/', function($m) use ($career_data) { return wp_json_encode(m2_career_data($career_data[$m[1]]), JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT); }, $html);
$html=preg_replace_callback('/\{\{([tu]):([a-z0-9_]+)\}\}/', function($m) { return $m[1]==='u' ? esc_url(m2_url(m2_value($m[2]))) : esc_html(m2_value($m[2])); },$html);
// Preserve the original standalone portfolio while retaining WordPress integration hooks.
remove_action('wp_head', '_wp_render_title_tag', 1);
ob_start(); wp_head(); $head = ob_get_clean();
ob_start(); wp_footer(); $foot = ob_get_clean();
$html = str_replace('</head>', $head.'<style>h1,h2,h3,h4,h5,h6{font-weight:700!important}button,.button,.primary-tab,.filter-button{font-weight:600!important}.work-card p{font-weight:500}</style></head>', $html);
$html = str_replace('</body>', $foot.'</body>', $html);
echo $html;
