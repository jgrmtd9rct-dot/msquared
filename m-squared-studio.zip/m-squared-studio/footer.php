<?php if (!defined('ABSPATH')) { exit; } m2_template('footer'); wp_footer(); ?></body></html>
