<?php
if (!defined('ABSPATH')) { exit; }
add_action('init', function() {
    register_post_type('m2_project', array('labels'=>array('name'=>'Projects','singular_name'=>'Project','add_new_item'=>'Add project','edit_item'=>'Edit project'),'public'=>false,'show_ui'=>true,'show_in_rest'=>true,'menu_icon'=>'dashicons-portfolio','supports'=>array('title','editor','thumbnail','page-attributes','revisions'),'capability_type'=>'post','map_meta_cap'=>true));
});
function m2_project_fields() { return array('category'=>'Project category','url'=>'Work URL (PDF, video, podcast, or website)','action'=>'Link label','image'=>'Preview image','home_title'=>'Homepage title (optional)','home_description'=>'Homepage description (optional)','home_category'=>'Homepage category (optional)','featured_order'=>'Homepage position (0 is first)'); }
add_action('add_meta_boxes', function() { add_meta_box('m2-project-details','Project details', 'm2_project_box','m2_project','normal','high'); });
function m2_project_box($post) {
    wp_nonce_field('m2_project_save','m2_project_nonce');
    echo '<p>The main editor holds the project description. Use a Featured Image or choose a preview below. Use Order in Page Attributes to arrange the full portfolio.</p>';
    foreach (m2_project_fields() as $key=>$label) {
        $value=get_post_meta($post->ID,'_m2_'.$key,true);
        echo '<p><label for="m2-'.esc_attr($key).'"><strong>'.esc_html($label).'</strong></label><br>';
        if ($key === 'home_description') { echo '<textarea rows="3" class="widefat" id="m2-'.esc_attr($key).'" name="m2_project['.esc_attr($key).']">'.esc_textarea($value).'</textarea>'; }
        else { echo '<input class="widefat" id="m2-'.esc_attr($key).'" type="'.($key==='featured_order'?'number':'text').'" name="m2_project['.esc_attr($key).']" value="'.esc_attr($value).'">'; }
        if ($key==='image') { echo '<button type="button" class="button m2-pick" data-target="m2-image">Choose image</button>'; }
        echo '</p>';
    }
    echo '<p><label><input type="checkbox" name="m2_featured" value="1" '.checked(get_post_meta($post->ID,'_m2_featured',true),'1',false).'> Show on the homepage</label></p>';
}
add_action('save_post_m2_project', function($id) {
    if (wp_is_post_revision($id) || wp_is_post_autosave($id) || !isset($_POST['m2_project_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['m2_project_nonce'])),'m2_project_save') || !current_user_can('edit_post',$id)) { return; }
    $input=isset($_POST['m2_project']) && is_array($_POST['m2_project']) ? wp_unslash($_POST['m2_project']) : array();
    foreach (m2_project_fields() as $key=>$label) { $value=isset($input[$key]) && is_scalar($input[$key]) ? (string)$input[$key] : ''; $value=in_array($key,array('url','image'),true)?esc_url_raw($value):($key==='featured_order'?absint($value):sanitize_textarea_field($value)); update_post_meta($id,'_m2_'.$key,$value); }
    update_post_meta($id,'_m2_featured',isset($_POST['m2_featured'])?'1':'0');
});
function m2_project_cards($featured=false) {
    $args=array('post_type'=>'m2_project','post_status'=>'publish','posts_per_page'=>-1,'orderby'=>array('menu_order'=>'ASC','ID'=>'ASC'));
    if ($featured) { $args['meta_query']=array(array('key'=>'_m2_featured','value'=>'1')); }
    $posts=get_posts($args);
    if ($featured) { usort($posts,function($a,$b){return (int)get_post_meta($a->ID,'_m2_featured_order',true)<=>(int)get_post_meta($b->ID,'_m2_featured_order',true);}); }
    ob_start();
    foreach ($posts as $p) {
        $meta=function($key)use($p){return get_post_meta($p->ID,'_m2_'.$key,true);};
        $title=$featured && $meta('home_title') ? $meta('home_title') : get_the_title($p);
        $description=$featured && $meta('home_description') ? $meta('home_description') : wp_strip_all_tags($p->post_content);
        $category=$featured && $meta('home_category') ? $meta('home_category') : $meta('category');
        $image=get_the_post_thumbnail_url($p,'large') ?: m2_url($meta('image'));
        $url=m2_url($meta('url')); $tag=$url ? 'a' : 'div';
        if ($featured) {
            echo '<article class="selected-project"><'.$tag.($url?' href="'.esc_url($url).'" target="_blank" rel="noopener noreferrer" aria-label="'.esc_attr('Open '.$title.' (new tab)').'"':'').'>';
            if($image) { echo '<div class="selected-image"><img src="'.esc_url($image).'" alt="'.esc_attr($title.' project preview').'" width="960" height="720" loading="lazy">'.($url?'<span aria-hidden="true"><svg class="m2-arrow-icon" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5 19 19 5M5 5h14v14"/></svg></span>':'').'</div>'; }
            echo '<div class="selected-caption"><p class="eyebrow">'.esc_html($category).'</p><h3>'.esc_html($title).'</h3><p>'.esc_html($description).'</p></div></'.$tag.'></article>';
        } else {
            echo '<article class="work-entry"><'.$tag.' class="project-image"'.($url?' href="'.esc_url($url).'" target="_blank" rel="noopener noreferrer" aria-label="'.esc_attr('Open '.$title.' (new tab)').'"':'').'>';
            if($image) { echo '<img src="'.esc_url($image).'" alt="'.esc_attr($title.' project preview').'" width="1200" height="900" loading="lazy">'; }
            if($url) { echo '<span class="project-open" aria-hidden="true"><svg class="m2-arrow-icon" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5 19 19 5M5 5h14v14"/></svg></span>'; }
            echo '</'.$tag.'><p class="eyebrow">'.esc_html($category).'</p><h2>'.esc_html($title).'</h2><p>'.esc_html($description).'</p>';
            if($url) { echo '<a class="text-link" href="'.esc_url($url).'" target="_blank" rel="noopener noreferrer">'.esc_html($meta('action') ?: 'Open the work').' <span aria-hidden="true"><svg class="m2-arrow-icon" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5 19 19 5M5 5h14v14"/></svg></span><span class="screen-reader-text"> (new tab)</span></a>'; }
            echo '</article>';
        }
    }
    return ob_get_clean();
}
