<?php
if (!defined('ABSPATH')) { exit; }
function m2_groups() {return array('hero'=>'Hero & service tabs','services'=>'Services','selected'=>'Homepage work heading','approach'=>'Modern tools','about'=>'About Matt','contact'=>'Contact & booking','header'=>'Header & logos','footer'=>'Footer','work_intro'=>'Business portfolio intro','work_contact'=>'Business portfolio contact','career_intro'=>'Career · intro','career_work'=>'Career · work samples','career_experience'=>'Career · experience','career_skills'=>'Career · skills','career_resume'=>'Career · summary & education','career_contact'=>'Career · contact');}
add_action('admin_menu',function(){add_menu_page('Studio Content','Studio Content','manage_options','m2-studio','m2_admin_page','dashicons-art',21);});
add_action('admin_enqueue_scripts',function($hook){
    $screen=get_current_screen();
    if ($hook==='toplevel_page_m2-studio' || ($screen && $screen->post_type==='m2_project')) {
        wp_enqueue_media(); wp_enqueue_script('m2-admin',get_template_directory_uri().'/assets/admin.js',array('jquery'),M2_STUDIO_VERSION,true);wp_enqueue_style('m2-admin',get_template_directory_uri().'/assets/admin.css',array(),M2_STUDIO_VERSION);
    }
});
function m2_admin_page(){
    if(!current_user_can('manage_options')){return;}
    $groups=m2_groups();$tab=isset($_GET['tab'])?sanitize_key($_GET['tab']):'setup';if(!isset($groups[$tab]) && $tab!=='setup'){$tab='setup';}
    echo '<div class="wrap m2-admin"><h1>M Squared · Studio Content</h1><p>Edit words, images, and links here. The design and motion stay in place. Manage portfolio items under <a href="'.esc_url(admin_url('edit.php?post_type=m2_project')).'">Projects</a>.</p>';
    if(isset($_GET['saved'])){echo '<div class="notice notice-success"><p>Changes saved.</p></div>';}
    if(isset($_GET['setup_done'])){echo '<div class="notice notice-success"><p>Starter content checked. Existing pages were preserved. See the setup notes below for page assignments.</p></div>';}
    echo '<nav class="nav-tab-wrapper"><a class="nav-tab '.($tab==='setup'?'nav-tab-active':'').'" href="'.esc_url(admin_url('admin.php?page=m2-studio')).'">Start here</a>';
    foreach($groups as $key=>$label){echo '<a class="nav-tab '.($tab===$key?'nav-tab-active':'').'" href="'.esc_url(admin_url('admin.php?page=m2-studio&tab='.$key)).'">'.esc_html($label).'</a>'; }echo '</nav>';
    if($tab==='setup'){
        echo '<div class="m2-panel"><h2>Set up the approved design</h2><p>The theme displays the studio homepage automatically. This button adds the nine original projects and creates missing <strong>/mywork</strong> and <strong>/portfolio</strong> pages. It never overwrites an existing page or deletes posts.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="m2_setup">';wp_nonce_field('m2_setup');submit_button('Create missing pages and starter projects');echo '</form>';
        foreach(array('mywork'=>'M Squared Business Portfolio','portfolio'=>'Your existing career template, or Preserved Career Portfolio') as $slug=>$template){$page=get_page_by_path($slug);echo '<p><strong>/'.esc_html($slug).'</strong>: ';if($page){echo '<a href="'.esc_url(get_edit_post_link($page->ID)).'">Edit page</a> · Current template: '.esc_html(get_page_template_slug($page->ID) ?: 'Default');}else{echo 'Not created yet.';}echo '<br>Use: '.esc_html($template).'</p>';}
        echo '<p><strong>Existing career portfolio:</strong> its page is preserved. If it depended on the previous custom theme’s PHP template, assign “Preserved Career Portfolio” to that page. If its content uses your page builder, keep its existing template and required plugins.</p><p>The previous <code>/work</code> address redirects to <code>/mywork/</code>. Under Settings → Permalinks, save once after setup.</p></div>';
        echo '<div class="m2-panel"><h2>Retire the blog</h2><p>Enable after backing up WordPress. This returns a “Gone” page for blog posts, archives, feeds, and /blog. Posts remain in the dashboard; no content is deleted.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="m2_blog">';wp_nonce_field('m2_blog');echo '<label><input type="checkbox" name="retire" value="1" '.checked(get_option('m2_retire_blog',false),true,false).'> Retire public blog pages</label>';submit_button('Save blog setting');echo '</form></div>';
    }else{
        echo '<form class="m2-panel" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="m2_save_content"><input type="hidden" name="group" value="'.esc_attr($tab).'">';wp_nonce_field('m2_content_'.$tab);
        echo '<h2>'.esc_html($groups[$tab]).'</h2><p>Career fields affect only the bundled Preserved Career Portfolio template. Studio fields affect the new business website.</p><p>Field labels show the original text so you can locate each item. Blank fields remain blank. Choose an image from the Media Library or upload a replacement.</p>';
        foreach(m2_fields() as $key=>$field){if($field['group']!==$tab){continue;}$value=m2_value($key);echo '<div class="m2-field"><label for="'.esc_attr($key).'">'.esc_html($field['label']).'</label>';
            if($field['type']==='textarea'){echo '<textarea rows="4" id="'.esc_attr($key).'" name="content['.esc_attr($key).']">'.esc_textarea($value).'</textarea>';}
            else {echo '<input type="text" id="'.esc_attr($key).'" name="content['.esc_attr($key).']" value="'.esc_attr($value).'">';}
            if($field['type']==='image'){echo '<button type="button" class="button m2-pick" data-target="'.esc_attr($key).'">Choose image</button><img class="m2-image-preview" src="'.esc_url(m2_url($value)).'" alt="Current image">';}
            echo '</div>';
        }submit_button('Save this section');echo '</form>';
    }echo '</div>';
}
add_action('admin_post_m2_save_content',function(){
    if(!current_user_can('manage_options')){wp_die('Not allowed.');}
    $group=isset($_POST['group'])?sanitize_key($_POST['group']):'';check_admin_referer('m2_content_'.$group);
    $input=isset($_POST['content']) && is_array($_POST['content'])?wp_unslash($_POST['content']):array();$values=get_option('m2_studio_content',array());
    foreach(m2_fields() as $key=>$field){if($field['group']!==$group || !isset($input[$key]) || !is_scalar($input[$key])){continue;}$values[$key]=in_array($field['type'],array('url','image'),true)?esc_url_raw($input[$key]):sanitize_textarea_field($input[$key]);}
    update_option('m2_studio_content',$values);wp_safe_redirect(admin_url('admin.php?page=m2-studio&tab='.$group.'&saved=1'));exit;
});
function m2_seed_content(){
    foreach(array('mywork'=>array('My work','page-mywork.php'),'portfolio'=>array('Career portfolio','template-career.php')) as $slug=>$page){
        if(!get_page_by_path($slug)){$id=wp_insert_post(array('post_type'=>'page','post_status'=>'publish','post_name'=>$slug,'post_title'=>$page[0]),true);if(!is_wp_error($id)){update_post_meta($id,'_wp_page_template',$page[1]);}}
    }
    if(!get_option('m2_starter_projects_imported')){
        foreach(json_decode(file_get_contents(__DIR__.'/projects.json'),true) as $i=>$p){
            $existing=get_posts(array('post_type'=>'m2_project','post_status'=>'any','meta_key'=>'_m2_seed','meta_value'=>(string)$i,'fields'=>'ids'));
            if($existing){continue;}
            $id=wp_insert_post(array('post_type'=>'m2_project','post_status'=>'publish','post_title'=>$p['title'],'post_content'=>$p['description'],'menu_order'=>$p['order']),true);
            if(is_wp_error($id)){return $id;}
            foreach(m2_project_fields() as $key=>$label){update_post_meta($id,'_m2_'.$key,$p[$key]??'');}
            update_post_meta($id,'_m2_featured',$p['featured']?'1':'0');update_post_meta($id,'_m2_seed',(string)$i);
        }update_option('m2_starter_projects_imported',true);
    }return true;
}
add_action('admin_post_m2_setup',function(){if(!current_user_can('manage_options')){wp_die('Not allowed.');}check_admin_referer('m2_setup');$result=m2_seed_content();if(is_wp_error($result)){wp_die(esc_html($result->get_error_message()));}flush_rewrite_rules();wp_safe_redirect(admin_url('admin.php?page=m2-studio&setup_done=1'));exit;});
add_action('admin_post_m2_blog',function(){if(!current_user_can('manage_options')){wp_die('Not allowed.');}check_admin_referer('m2_blog');update_option('m2_retire_blog',isset($_POST['retire']));wp_safe_redirect(admin_url('admin.php?page=m2-studio&saved=1'));exit;});
