<?php
if (!defined('ABSPATH')) exit;
function m2_share_image() { return get_template_directory_uri().'/assets/social-preview.png'; }
add_filter('wpseo_opengraph_image','m2_share_image');
add_filter('wpseo_twitter_image','m2_share_image');
add_filter('rank_math/opengraph/facebook/image','m2_share_image');
add_filter('rank_math/opengraph/twitter/image','m2_share_image');
add_action('wp_head',function(){
 if (defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION')) return;
 $title=is_front_page() ? 'M Squared Digital Studio' : wp_get_document_title();
 $url=is_singular() ? get_permalink() : home_url('/');
 $description='Accessible creative services for websites, branding, and content. Modern tools. A human touch.';
 $tags=array('og:type'=>'website','og:site_name'=>'M Squared Digital Studio','og:title'=>$title,'og:description'=>$description,'og:url'=>$url,'og:image'=>m2_share_image(),'og:image:width'=>'1200','og:image:height'=>'630','og:image:type'=>'image/png','og:image:alt'=>'M Squared Digital Studio — Accessible creative services for websites, branding, and content');
 foreach($tags as $key=>$value) echo '<meta property="'.esc_attr($key).'" content="'.esc_attr($value).'">';
 foreach(array('twitter:card'=>'summary_large_image','twitter:title'=>$title,'twitter:description'=>$description,'twitter:image'=>m2_share_image(),'twitter:image:alt'=>$tags['og:image:alt']) as $key=>$value) echo '<meta name="'.esc_attr($key).'" content="'.esc_attr($value).'">';
},5);

add_action('wp_head',function(){ echo '<style>.m2-arrow-icon{display:inline-block;width:1em;height:1em;vertical-align:-.125em;flex-shrink:0;overflow:visible}</style>'; },6);
