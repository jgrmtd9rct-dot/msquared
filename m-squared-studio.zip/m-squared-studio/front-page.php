<?php get_header(); m2_template('home'); get_footer();
