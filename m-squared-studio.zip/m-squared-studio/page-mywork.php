<?php
/* Template Name: M Squared Business Portfolio */
get_header(); m2_template('work'); get_footer();
