# M Squared Studio — WordPress installation and editing

This package is an installable custom WordPress theme. Your website, domain, and email can remain at IONOS. No domain transfer, DNS change, new hosting service, or paid page-builder plugin is required.

## What to upload

Upload **M-Squared-Studio-WordPress-Theme.zip** through WordPress. Do not upload the earlier React website source ZIP. This theme includes the design, animations, logos, studio fonts, photography, and original PDF work samples.

The theme requires WordPress 6.6 or later and PHP 8.0 or later. It was tested locally with WordPress 7.1 and PHP 8.5.4; your IONOS installation and plugins still need a staging check.

## Install at IONOS

1. Back up your WordPress database and website files, including the existing custom theme and uploads. Keep the old theme installed for rollback.
2. Use a staging copy of the current WordPress site if your IONOS plan provides one. Otherwise, ask IONOS to help create a staging copy. Use it to check compatibility with your existing plugins and career page.
3. Sign in to that WordPress dashboard. Go to **Appearance → Themes → Add New Theme → Upload Theme**.
4. Choose **M-Squared-Studio-WordPress-Theme.zip**, click **Install Now**, then activate **M Squared Studio** on staging.
5. Open **Studio Content → Start here**. Click **Create missing pages and starter projects**. This adds nine projects and creates missing portfolio pages. It does not overwrite existing pages or delete posts. Repeating setup does not duplicate the imported projects.
6. Check **Pages → All Pages**:
   - **/mywork/** is the business portfolio. Assign the **M Squared Business Portfolio** template if needed.
   - **/portfolio/** remains the career portfolio. If its previous design depended on your old custom theme, assign **Preserved Career Portfolio**. If it uses page content or a page-builder plugin you wish to retain, keep that page and its required plugin; verify its layout on staging.
7. Go to **Settings → Permalinks** and click **Save Changes** once. The old **/work/** address redirects to **/mywork/**.
8. Under **Studio Content → Start here**, enable **Retire public blog pages** and save. Old posts, archives, feeds, and /blog return a 410 “Gone” page, while the stored posts remain in WordPress. Nothing is permanently deleted. Review any other custom blog URLs you used; custom routes from plugins may need separate handling.
9. Review the homepage, both portfolios, service tabs, expandable service details, mobile menu, light/dark switch, PDFs, videos, email link, and booking destination. Clear any cache after updates. Check the site while logged out as well as logged in.
10. When staging looks right, use your IONOS staging-to-live process, or install and configure the same theme on the live WordPress site. If you edited staging content, move the corresponding WordPress database/content too: uploading the theme ZIP alone does not transfer saved edits or projects.

The homepage uses the theme’s designed front-page template. Its copy is managed in Studio Content, so an old WordPress homepage’s body content is preserved in the database but is not displayed by this front-page template.

If the ZIP exceeds your WordPress upload limit, ask IONOS to increase it or upload the unzipped **m-squared-studio** folder using SFTP into **wp-content/themes/**. Activate it from Appearance → Themes afterward.

## Everyday editing

### Studio homepage and shared content

Open **Studio Content** in the WordPress sidebar. Choose a section, edit the labeled fields, and click **Save this section**.

- **Hero & service tabs:** headline lines, introduction, call-to-action label, and all three service-tab panels.
- **Services:** service descriptions, images, and the scope/process/handoff details.
- **Homepage work heading:** heading and links surrounding the featured projects.
- **Modern tools:** photos, heading, and human-centered approach copy.
- **About Matt:** portrait, introduction, background, and experience note.
- **Contact & booking:** contact copy, email destination, and shared booking URL. If your email changes, update both its visible label and its mailto link.
- **Header & logos:** light/dark logo images, alternative descriptions, and navigation labels. Mobile and desktop navigation labels have separate fields.
- **Footer:** studio footer copy and external support link.
- **Business portfolio intro/contact:** text surrounding the project grid at /mywork.

Fields preserve the approved layout rather than exposing raw page code. Image fields have a **Choose image** button using the WordPress Media Library. Upload a replacement or choose an existing image, then update the accompanying photo description where applicable. Use a high-resolution landscape image for project and service previews.

Headings use bold weights, and button/navigation labels use semibold weights. The italic headings remain at least medium weight. Brand colors and layout are held in the theme styles so routine copy edits do not accidentally change them.

### Business projects

Go to **Projects → Add project**, or open an existing project.

- **Title:** full business-portfolio project title.
- **Main editor:** project description. The cards present this as plain text.
- **Featured Image:** preferred project preview. If you do not set one, the Preview image field is used.
- **Project details:** category, destination URL, link label, and optional homepage-specific title, description, and category.
- **Show on the homepage:** includes the project in Selected Work.
- **Homepage position:** lower numbers appear first; the first selected project has the larger desktop layout.
- **Order** in Page Attributes: lower numbers appear first in /mywork.

Click **Publish** or **Update**. Draft projects do not appear publicly. There are no separate public project-detail pages: project links open the PDF, video, podcast, or website you specify. To remove a project from public view, change its status to Draft or move it to Trash.

The original nine projects are imported once. Removing one afterward does not cause setup to recreate it. Business projects are stored separately from the career portfolio, so editing a business description does not rewrite your job-search copy.

### Career portfolio

The optional **Preserved Career Portfolio** template retains the original portfolio, résumé, and contact-tab design at /portfolio. Its editing fields are under the **Career** tabs in Studio Content:

- Intro and visible page labels.
- Existing work-sample titles, descriptions, preview images, and media URLs.
- Existing experience entries and their bullet points.
- Skills, professional summary, education, and contact information.

These fields update the bundled template only. If you retain a different existing page-builder portfolio, continue editing it through its original editor. The career template keeps its existing light appearance; the new studio homepage and /mywork use the new light/dark switch.

Adding extra career experience rows or changing the career portfolio’s structure requires a theme code change. Everyday text changes to the existing entries do not. New business projects can be added freely through Projects.

## Appearance and motion

The design retains the approved photo tilt in About and the overlapping photos in Modern tools. The hero card, service label, and business project cards stay straight. The studio pages retain their cinematic entrances, scroll reveals, hover effects, and mobile menu. Reduced-motion preferences disable the added motion.

The browser theme color is **#2D46B9**, your brand blue, on all bundled templates. Supporting browsers may use it for their toolbar or tab tint. Browser version, layout, and user settings determine the exact result; the in-app preview does not demonstrate every browser’s toolbar behavior.

## What was checked

- Theme activation and PHP syntax in a real local WordPress installation.
- Homepage, /mywork, and /portfolio returning successful responses.
- Nine business projects and three homepage features.
- Text edited and saved through Studio Content, then verified on the rendered page.
- Project-field saving, URL sanitization, nonce checks, and output escaping.
- Repeated setup without duplicate projects or overwritten career-page content.
- Local page assets and bundled font paths.
- Desktop light/dark views and 390px mobile layout; core headings and buttons at medium-or-heavier weights.
- Service tabs, mobile menu/Escape dismissal, and theme-switch containment in both modes.
- /work redirect and retired blog/post responses.
- Career gallery rendering after conversion to editable fields.

This is a focused development review, not a full WCAG conformance audit or an audit of third-party video, podcast, booking, PDF, or plugin content. Check your actual IONOS site before launch.

## Backups and future updates

Content settings live in the WordPress database; projects are stored as WordPress project records. Include the database, Media Library, and theme folder in backups. Switching themes does not delete those records, but the Projects editor is registered by this theme and becomes available again when the theme is reactivated.

The ZIP includes all theme source. There is no automatic theme-update service. Keep your customized version and apply future theme updates deliberately. If a launch causes trouble, reactivate the previous theme; the new setup does not erase the old page content or blog posts.

No changes have been made to your IONOS account, DNS, or live WordPress installation.

## References

- [WordPress: installing and working with themes](https://wordpress.org/documentation/article/work-with-themes/)
- [IONOS: WordPress staging](https://www.ionos.com/digitalguide/hosting/blogs/setting-up-wordpress-staging/)
- [WebKit: browser theme-color support](https://webkit.org/blog/11989/new-webkit-features-in-safari-15/)
