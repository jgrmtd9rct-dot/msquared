<?php
/** M Squared Studio. Content stays in WordPress options and project records. */
if (!defined('ABSPATH')) { exit; }
define('M2_STUDIO_VERSION', '1.0.3');
function m2_fields() { static $fields; if ($fields === null) { $fields = json_decode(file_get_contents(__DIR__.'/inc/fields.json'), true); } return $fields; }
function m2_value($key) { $values = get_option('m2_studio_content', array()); $fields = m2_fields(); return isset($values[$key]) ? $values[$key] : ($fields[$key]['default'] ?? ''); }
function m2_url($url) {
    if (str_starts_with($url, '/images/') || str_starts_with($url, '/wp-content/uploads/')) {
        if (is_file(__DIR__.'/assets'.$url)) { return get_template_directory_uri().'/assets'.$url; }
    }
    if (str_starts_with($url, '/')) { return home_url($url); }
    return $url;
}
function m2_template($name) {
    if (!in_array($name, array('header','footer','home','work'), true)) { return; }
    $markup = file_get_contents(__DIR__.'/templates/'.$name.'.html');
    $markup = preg_replace_callback('/\{\{([tu]):([a-z0-9_]+)\}\}/', function($m) { return $m[1] === 'u' ? esc_url(m2_url(m2_value($m[2]))) : esc_html(m2_value($m[2])); }, $markup);
    $markup = str_replace('{{year}}', esc_html(wp_date('Y')), $markup);
    $markup = preg_replace_callback('/\{\{projects:(featured|all)\}\}/', function($m) { return m2_project_cards($m[1] === 'featured'); }, $markup);
    $markup = preg_replace_callback('/href="(\/[^"<>]*)"/', function($m) { return 'href="'.esc_url(home_url(html_entity_decode($m[1], ENT_QUOTES))).'"'; }, $markup);
    $markup = preg_replace_callback('~>([^<]*)<~', function($m) { return str_replace('↗', '<svg class="m2-arrow-icon" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5 19 19 5M5 5h14v14"/></svg>', $m[0]); }, $markup);
    echo $markup; // Trusted theme template, all editor values escaped above.
}
add_action('after_setup_theme', function() {
    add_theme_support('title-tag'); add_theme_support('post-thumbnails'); add_theme_support('responsive-embeds');
    add_theme_support('html5', array('search-form','comment-form','gallery','caption','style','script'));
    add_theme_support('editor-styles'); add_editor_style('assets/editor.css');
});
add_action('wp_enqueue_scripts', function() {
    if (is_page_template('template-career.php')) { return; }
    wp_enqueue_style('m2-studio', get_template_directory_uri().'/assets/site.css', array(), M2_STUDIO_VERSION);
    wp_enqueue_style('m2-wordpress', get_template_directory_uri().'/assets/wordpress.css', array('m2-studio'), M2_STUDIO_VERSION);
    wp_enqueue_script('m2-studio', get_template_directory_uri().'/assets/site.js', array(), M2_STUDIO_VERSION, true);
});
add_action('wp_head', function() {
    echo '<meta name="theme-color" content="#2D46B9">';
    echo '<script>try{var t=localStorage.getItem("m2-theme");document.documentElement.dataset.theme=t==="dark"||(!t&&matchMedia("(prefers-color-scheme: dark)").matches)?"dark":"light"}catch(e){}</script>';
    if (!has_site_icon()) { echo '<link rel="icon" href="'.esc_url(get_template_directory_uri().'/assets/favicon.png').'">'; }
}, 1);
require_once __DIR__.'/inc/projects.php';
require_once __DIR__.'/inc/admin.php';
add_action('template_redirect', function() {
    if (is_admin() || is_preview()) { return; }
    $path = untrailingslashit((string) wp_parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH));
    $old = untrailingslashit((string) wp_parse_url(home_url('/work'), PHP_URL_PATH));
    if ($path === $old) { wp_safe_redirect(home_url('/mywork/'), 301); exit; }
    if (get_option('m2_retire_blog', false) && (is_singular('post') || is_category() || is_tag() || is_date() || is_author() || is_feed() || preg_match('~/blog(?:/|$)~', $path))) {
        status_header(410); nocache_headers(); get_header(); echo '<main id="main" tabindex="-1" class="section"><h1>This journal has retired.</h1><p>The studio and both portfolios are still here.</p><a class="text-link" href="'.esc_url(home_url('/')).'">Visit M Squared Digital Studio <svg class="m2-arrow-icon" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5 19 19 5M5 5h14v14"/></svg></a></main>'; get_footer(); exit;
    }
});

require_once __DIR__.'/inc/sharing.php';
