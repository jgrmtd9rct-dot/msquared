(() => {
 'use strict';
 const reduced = matchMedia('(prefers-reduced-motion: reduce)');
 const systemTheme = matchMedia('(prefers-color-scheme: dark)');
 const toggle = document.querySelector('.theme-switch');
 function syncTheme(next) {
  document.documentElement.dataset.theme=next?'dark':'light';
  if(!toggle)return;
  toggle.setAttribute('aria-checked',String(next));
  toggle.toggleAttribute('data-checked',next);
  toggle.toggleAttribute('data-unchecked',!next);
  toggle.querySelector('[data-slot=switch-thumb]').toggleAttribute('data-checked',next);
 }
 function preferredTheme(){let saved;try{saved=localStorage.getItem('m2-theme');}catch{}return saved?saved==='dark':systemTheme.matches;}
 syncTheme(preferredTheme());
 systemTheme.addEventListener('change',()=>syncTheme(preferredTheme()));
 toggle?.addEventListener('click',()=>{const next=toggle.getAttribute('aria-checked')!=='true';syncTheme(next);try{localStorage.setItem('m2-theme',next?'dark':'light');}catch{}});
 const menu=document.querySelector('#studio-menu'), opener=document.querySelector('.mobile-menu-trigger');
 if(menu && opener){
  opener.addEventListener('click',()=>{menu.showModal();opener.setAttribute('aria-expanded','true');});
  menu.querySelector('.menu-close').addEventListener('click',()=>menu.close());
  menu.addEventListener('close',()=>{opener.setAttribute('aria-expanded','false');opener.focus();});
  menu.addEventListener('click',e=>{if(e.target===menu && (e.clientX<menu.getBoundingClientRect().left || e.clientX>menu.getBoundingClientRect().right))menu.close();});
  menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>menu.close()));
  matchMedia('(min-width: 721px)').addEventListener('change',e=>{if(e.matches && menu.open)menu.close();});
 }
 document.querySelectorAll('.desk-tabs').forEach(root=>{
  const tabs=Array.from(root.querySelectorAll('[role=tab]'));
  function select(tab){tabs.forEach(t=>{const active=t===tab;t.setAttribute('aria-selected',String(active));t.tabIndex=active?0:-1;t.toggleAttribute('data-active',active);document.getElementById(t.getAttribute('aria-controls')).hidden=!active;});}
  tabs.forEach((tab,i)=>{
   tab.addEventListener('click',()=>select(tab));
   tab.addEventListener('keydown',e=>{let next;if(e.key==='ArrowRight')next=(i+1)%tabs.length;else if(e.key==='ArrowLeft')next=(i+tabs.length-1)%tabs.length;else if(e.key==='Home')next=0;else if(e.key==='End')next=tabs.length-1;else return;e.preventDefault();tabs[next].focus();select(tabs[next]);});
  });
 });
 let stopMotion=()=>{};
 function startMotion(){
  stopMotion();if(reduced.matches)return;
  const nodes=Array.from(document.querySelectorAll('.services>.section-top,.services>h2,.selected-work>h2,.selected-project,.photo-service,.approach-left,.approach-copy>p,.approach-copy>div,.about>.portrait,.about-copy,.contact>.eyebrow,.contact>h2,.contact-bottom,.work-entry'));
  const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('scroll-ready');observer.unobserve(e.target);}}),{rootMargin:'0px 0px -40px 0px'});
  nodes.forEach((node,i)=>{if(node.getBoundingClientRect().top<innerHeight-40)return;node.dataset.enter=node.matches('.approach-left,.portrait')?'left':node.matches('.about-copy,.approach-copy>div,.approach-copy>p')?'right':node.matches('.photo-service')?(i%2?'left':'right'):'up';node.style.setProperty('--enter-delay',`${node.matches('.selected-project,.work-entry')?(i%3)*90:0}ms`);node.classList.add('scroll-enter');observer.observe(node);});
  const focused=e=>e.target.closest('.scroll-enter')?.classList.add('scroll-ready');document.addEventListener('focusin',focused);
  let frame=0;const desktop=matchMedia('(min-width:900px) and (pointer:fine)');
  const scenes=Array.from(document.querySelectorAll('.studio-entrance,.selected-image,.approach-photos'));const visible=new Set();
  function render(){frame=0;if(!desktop.matches){scenes.forEach(n=>n.style.removeProperty('--scene-shift'));return;}const positions=Array.from(visible).map(n=>({n,r:n.getBoundingClientRect()}));positions.forEach(({n,r})=>{const progress=Math.max(-1,Math.min(1,(innerHeight/2-r.top-r.height/2)/(innerHeight/2+r.height/2)));n.style.setProperty('--scene-shift',`${(progress*24).toFixed(2)}px`);});}
  function schedule(){if(!frame&&!document.hidden)frame=requestAnimationFrame(render);}
  const scenesObserver=new IntersectionObserver(entries=>{entries.forEach(e=>e.isIntersecting?visible.add(e.target):visible.delete(e.target));schedule();},{rootMargin:'80px'});scenes.forEach(n=>scenesObserver.observe(n));
  window.addEventListener('scroll',schedule,{passive:true});window.addEventListener('resize',schedule);document.addEventListener('visibilitychange',schedule);
  stopMotion=()=>{observer.disconnect();scenesObserver.disconnect();cancelAnimationFrame(frame);document.removeEventListener('focusin',focused);window.removeEventListener('scroll',schedule);window.removeEventListener('resize',schedule);document.removeEventListener('visibilitychange',schedule);nodes.forEach(n=>{n.classList.remove('scroll-enter','scroll-ready');n.removeAttribute('data-enter');n.style.removeProperty('--enter-delay');});scenes.forEach(n=>n.style.removeProperty('--scene-shift'));};
 }
 if('IntersectionObserver' in window){startMotion();reduced.addEventListener('change',startMotion);}
})();
